
  # Responsive SPA with Advanced Features

  This is a code bundle for Responsive SPA with Advanced Features. The original project is available at https://www.figma.com/design/dWt7HDZ5obJR8masXGnDTh/Responsive-SPA-with-Advanced-Features.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  